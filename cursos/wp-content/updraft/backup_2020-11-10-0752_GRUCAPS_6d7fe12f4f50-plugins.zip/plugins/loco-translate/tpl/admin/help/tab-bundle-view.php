<h2>
    Bundle overview
</h2>
<p>
    The Overview tab lists each set of available translations in the current bundle.
</p>
<p>
    If Loco Translate can't configure your bundle automatically, click the Setup tab to see your options.
</p>